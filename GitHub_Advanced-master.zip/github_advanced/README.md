实战课[最新版react native+redux打造高质量上线app](https://coding.imooc.com/class/304.html)

## 概述
- 课程文档查看[doc](https://git.imooc.com/coding-304/GitHub_Advanced/src/master/doc);
- 课程中所用到的demo查看[demo](https://git.imooc.com/coding-304/GitHub_Advanced/src/master/demo);
- 更多demo可查看[demo](https://github.com/crazycodeboy/RNStudyNotes/tree/master/Demo);
- 课程源码，可通过git查看课程各章节的源码；


## 如何运行？

1. 在项目根目录执行`npm install`或`yarn install`;
2. 切换到ios目录下执行`pod install`;
3. 然后运行 react-native run-ios 或 react-native run-android；
4. Ok,有问题可以提issues出来;

