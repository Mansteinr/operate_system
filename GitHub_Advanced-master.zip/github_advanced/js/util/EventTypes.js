export default {
    bottom_tab_select:'bottom_tab_select',
    favorite_changed_popular:'favorite_changed_popular',
    favoriteChanged_trending:'favoriteChanged_trending',
}