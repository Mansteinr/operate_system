const {NativeModules} = require('react-native');
module.exports = NativeModules.UMAnalyticsModule;