/**
 * Trending搜索时间跨度mo
 * @param showText
 * @param searchText
 * @constructor
 */
export default function TimeSpan(showText, searchText) {
    this.showText = showText;
    this.searchText = searchText;
}