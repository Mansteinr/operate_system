import { AppRegistry } from 'react-native';
import App from './App';

AppRegistry.registerComponent('react_navigation_demo', () => App);
